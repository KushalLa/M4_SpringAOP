package com.test;

public class Account {

	
	public void withdraw()
	{
		System.out.println("Account Withdraw");
	}
	/*2.public int withdraw()
	{
		System.out.println("Account Withdraw");
		return (100);
	}*/
	
	/*3.public int withdraw(int amt)
	{
		if(amt==0)
		{
			throw new ArithmeticException("Amount Zero");
		}
		return amt;
	}*/
}
