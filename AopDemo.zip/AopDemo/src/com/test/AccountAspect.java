package com.test;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;


@Aspect
public class AccountAspect {

//	@Before("execution (public void com.test.Account.withdraw())")
//	@Before("execution (* com.test.*.*())")
//	@Around("adviceToAll()")
	/*public Object beforeAdvice(ProceedingJoinPoint pjp) throws Throwable 
	{*/
		/*System.out.println("Before Advice Called");
		long start=System.currentTimeMillis();
		Object obj=pjp.proceed();
		long stop=System.currentTimeMillis();
		System.out.println("After Advice Called");
		System.out.println("Time = "+(stop-start));*/
		/*2.System.out.println("Before");
		Object obj=pjp.proceed();
		int amt=(Integer)obj;
		System.out.println("After Withdraw Amount= "+amt);
		return(obj);*/
//	}
	
//	@Around("adviceToAll()")
	public void beforeAdvice()
	{
		System.out.println("before Advice");
	}
	
//	@Pointcut("execution (* com.test.*.*())") //.. is for parameterized methods
	public void adviceToAll()
	{
		
	}
}
